package Dicegame;
import java.util.Scanner;

public class Dicegame {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);

		        // Input first dice value
		        System.out.println("Enter Value 1:");
		        int value1 = scanner.nextInt();

		        // Validate input range
		        if (!isValidInput(value1)) {
		            System.out.println("Invalid Input");
		            return;
		        }

		        // Input second dice value
		        System.out.println("Enter Value 2:");
		        int value2 = scanner.nextInt();

		        // Validate input range
		        if (!isValidInput(value2)) {
		            System.out.println("Invalid Input");
		            return;
		        }

		        // Calculate points
		        int sum = value1 + value2;
		        int points;

		        if (sum < 8) {
		            points = Math.abs(8 - sum);
		        } else {
		            points = 2 * Math.abs(8 - sum);
		        }

		        // Output the points scored
		        System.out.println("The points scored is " + points);

		        scanner.close();
		    }

		    // Function to validate input range
		    public static boolean isValidInput(int value) {
		        return value >= 0 && value <= 6;
		    }
		

	}


