/**
 * 
 */
/**
 * @author thiru
 *
 */
module Dicegame {
}